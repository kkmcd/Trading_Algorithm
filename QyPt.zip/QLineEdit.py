import sys
from PyQt5.QtWidgets import *

class MyWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setupUI()

    def setupUI(self):
        self.setGeometry(800,400,300,150)

        #Label
        label = QLabel("종목코드",self) #다른 메소드에서 사용할 일이 없기 때문에 self를 붙이지 않음
        label.move(20,20)

        #Line Edit
        self.lineEdit = QLineEdit("",self) #self.lineEdit라고 붙인 이유. 다른 메소드에서 사용해야되기 때문
        self.lineEdit.move(80, 20) #self가 없으면 local var 있으면 instance가 됨
        self.lineEdit.textChanged.connect(self.lineEditChanged)

        #StatusBar
        self.statusBar = QStatusBar(self)
        self.setStatusBar(self.statusBar) #상속받은거임

    def lineEditChanged(self): #
        self.statusBar.showMessage(self.lineEdit.text())

if __name__ == "__main__":
     app = QApplication(sys.argv)
     mywindow = MyWindow()
     mywindow.show()
     app.exec_()


